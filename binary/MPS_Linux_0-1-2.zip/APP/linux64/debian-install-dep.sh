echo "+---------------------------+"
echo "|                           |"
echo "|   Moving Picture Studio   | Debian/Ubuntu dependency installer" 
echo "|                           |"
echo "+---------------------------+"
echo "The script will try to install libsdl2-2.0-0 libsdl2-image-2.0-0 libsdl2-mixer-2.0-0 libsdl2-ttf-2.0-0 libglew2.0 libgl1"
echo ""
sudo apt -qq install libsdl2-2.0-0 libsdl2-image-2.0-0 libsdl2-mixer-2.0-0 libsdl2-ttf-2.0-0 libglew2.0 libgl1
